(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.opti1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-51.7,-9.9,54.9,15.7).beginStroke().moveTo(-34.6,12).curveTo(-37.9,12,-39.1,10.4).curveTo(-40.1,8.8,-39.2,5.3).lineTo(-36.4,-5.3).curveTo(-35.5,-8.8,-33.5,-10.4).curveTo(-31.5,-12,-28.2,-12).lineTo(-20.2,-12).curveTo(-16.8,-12,-15.7,-10.4).curveTo(-14.6,-8.8,-15.5,-5.3).lineTo(-18.4,5.3).curveTo(-19.3,8.8,-21.3,10.4).curveTo(-23.3,12,-26.6,12).closePath().moveTo(-30.6,-5.3).lineTo(-33.5,5.3).curveTo(-34,7.3,-32.1,7.3).lineTo(-26.6,7.3).curveTo(-24.7,7.3,-24.1,5.3).lineTo(-21.3,-5.3).curveTo(-20.7,-7.3,-22.7,-7.3).lineTo(-28.1,-7.3).curveTo(-30,-7.3,-30.6,-5.3).closePath().moveTo(29.3,11.6).lineTo(31.9,2).lineTo(23.9,11.6).lineTo(17.9,11.6).lineTo(22.7,-6).lineTo(28.3,-6).lineTo(25.7,3.6).lineTo(33.7,-6).lineTo(39.7,-6).lineTo(34.9,11.6).closePath().moveTo(5.8,11.6).lineTo(9.3,-1.5).lineTo(4,-1.5).lineTo(5.2,-6).lineTo(21.4,-6).lineTo(20.2,-1.5).lineTo(14.9,-1.5).lineTo(11.4,11.6).closePath().moveTo(-6.4,11.6).lineTo(-2.9,-1.5).lineTo(-8.7,-1.5).lineTo(-12.2,11.6).lineTo(-17.8,11.6).lineTo(-13.1,-6).lineTo(3.9,-6).lineTo(-0.8,11.6).closePath();
	this.shape.setTransform(39.6923,11.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-51.7,-9.9,54.9,15.7).beginStroke().moveTo(-34.6,12).curveTo(-37.9,12,-39.1,10.4).curveTo(-40.1,8.8,-39.2,5.3).lineTo(-36.4,-5.3).curveTo(-35.5,-8.8,-33.5,-10.4).curveTo(-31.5,-12,-28.2,-12).lineTo(-20.2,-12).curveTo(-16.8,-12,-15.7,-10.4).curveTo(-14.6,-8.8,-15.5,-5.3).lineTo(-18.4,5.3).curveTo(-19.3,8.8,-21.3,10.4).curveTo(-23.3,12,-26.6,12).closePath().moveTo(-30.6,-5.3).lineTo(-33.5,5.3).curveTo(-34,7.3,-32.1,7.3).lineTo(-26.6,7.3).curveTo(-24.7,7.3,-24.1,5.3).lineTo(-21.3,-5.3).curveTo(-20.7,-7.3,-22.7,-7.3).lineTo(-28.1,-7.3).curveTo(-30,-7.3,-30.6,-5.3).closePath().moveTo(29.3,11.6).lineTo(31.9,2).lineTo(23.9,11.6).lineTo(17.9,11.6).lineTo(22.7,-6).lineTo(28.3,-6).lineTo(25.7,3.6).lineTo(33.7,-6).lineTo(39.7,-6).lineTo(34.9,11.6).closePath().moveTo(5.8,11.6).lineTo(9.3,-1.5).lineTo(4,-1.5).lineTo(5.2,-6).lineTo(21.4,-6).lineTo(20.2,-1.5).lineTo(14.9,-1.5).lineTo(11.4,11.6).closePath().moveTo(-6.4,11.6).lineTo(-2.9,-1.5).lineTo(-8.7,-1.5).lineTo(-12.2,11.6).lineTo(-17.8,11.6).lineTo(-13.1,-6).lineTo(3.9,-6).lineTo(-0.8,11.6).closePath();
	this.shape_1.setTransform(39.6923,11.975);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-14.2,-3.4,15.4,3.7).beginStroke().moveTo(-7.2,12).curveTo(-10.5,12,-11.7,10.4).curveTo(-12.7,8.8,-11.9,5.3).lineTo(-9,-5.3).curveTo(-8.1,-8.8,-6.1,-10.4).curveTo(-4.1,-12,-0.8,-12).lineTo(7.2,-12).curveTo(10.6,-12,11.7,-10.4).curveTo(12.7,-8.8,11.9,-5.3).lineTo(9,5.3).curveTo(8.1,8.8,6.1,10.4).curveTo(4.1,12,0.8,12).closePath().moveTo(-3.3,-5.3).lineTo(-6.1,5.3).curveTo(-6.7,7.3,-4.7,7.3).lineTo(0.7,7.3).curveTo(2.7,7.3,3.2,5.3).lineTo(6,-5.3).curveTo(6.7,-7.3,4.7,-7.3).lineTo(-0.7,-7.3).curveTo(-2.7,-7.3,-3.3,-5.3).closePath();
	this.shape_2.setTransform(12.25,11.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-11.7,-2.8,12.8,3.1).beginStroke().moveTo(0.6,8.8).lineTo(4.1,-4.3).lineTo(-1.7,-4.3).lineTo(-5.3,8.8).lineTo(-10.9,8.8).lineTo(-6.2,-8.8).lineTo(10.8,-8.8).lineTo(6.1,8.8).closePath();
	this.shape_3.setTransform(32.65,14.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-12.4,-3.1,10.4,2.3).beginStroke().moveTo(-6.9,8.8).lineTo(-3.4,-4.3).lineTo(-8.7,-4.3).lineTo(-7.5,-8.8).lineTo(8.7,-8.8).lineTo(7.5,-4.3).lineTo(2.2,-4.3).lineTo(-1.3,8.8).closePath();
	this.shape_4.setTransform(52.3,14.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-11.7,-2.8,12.7,3.1).beginStroke().moveTo(0.5,8.8).lineTo(3.1,-0.9).lineTo(-4.9,8.8).lineTo(-10.9,8.8).lineTo(-6.1,-8.8).lineTo(-0.5,-8.8).lineTo(-3.1,0.8).lineTo(4.9,-8.8).lineTo(10.9,-8.8).lineTo(6.1,8.8).closePath();
	this.shape_5.setTransform(68.425,14.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,79.4,24);


(lib.KOM = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-9.9,-2.3,10.6,2.6).beginStroke().moveTo(-4.3,8).lineTo(-2.7,2.3).lineTo(-7.9,2.3).lineTo(-6.6,-2.3).lineTo(-1.5,-2.3).lineTo(0,-8).lineTo(4.3,-8).lineTo(2.8,-2.3).lineTo(7.9,-2.3).lineTo(6.6,2.3).lineTo(1.5,2.3).lineTo(-0,8).closePath();
	this.shape.setTransform(66.625,8.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(2.6,8.9).lineTo(5,-0.1).lineTo(0.4,5.9).lineTo(-3.5,5.9).lineTo(-4.9,-0.1).lineTo(-7.4,8.9).lineTo(-12.7,8.9).lineTo(-7.9,-8.9).lineTo(-2.3,-8.9).lineTo(-0.1,0.5).lineTo(7.1,-8.9).lineTo(12.7,-8.9).lineTo(7.9,8.9).closePath();
	this.shape_1.setTransform(48.575,22.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-6,9.2).curveTo(-8.2,9.2,-9.1,7.8).curveTo(-10,6.3,-9.4,3.9).lineTo(-7.3,-3.9).curveTo(-6.6,-6.4,-5,-7.8).curveTo(-3.3,-9.2,-1,-9.2).lineTo(5.9,-9.2).curveTo(8.2,-9.2,9.1,-7.8).curveTo(10,-6.4,9.3,-3.9).lineTo(7.3,3.9).curveTo(6.6,6.3,4.9,7.8).curveTo(3.2,9.2,1,9.2).closePath().moveTo(-2.1,-3.4).lineTo(-3.9,3.3).curveTo(-4.3,4.7,-3.1,4.7).lineTo(0.5,4.7).curveTo(1.8,4.7,2.1,3.3).lineTo(3.9,-3.4).curveTo(4.2,-4.7,3.1,-4.7).lineTo(-0.6,-4.7).curveTo(-1.8,-4.7,-2.1,-3.4).closePath();
	this.shape_2.setTransform(28.2668,22.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.4,9).lineTo(-1.1,2.4).lineTo(-3.4,2.4).lineTo(-5.2,9).lineTo(-10.5,9).lineTo(-5.7,-8.8).lineTo(-0.4,-8.8).lineTo(-2.2,-2.2).lineTo(0.3,-2.2).lineTo(2.9,-5.8).curveTo(3.4,-6.6,3.9,-7.1).lineTo(5.1,-8.1).curveTo(5.6,-8.4,6.6,-8.8).curveTo(7.4,-9,8.2,-9.1).lineTo(9,-9).lineTo(10.5,-8.8).lineTo(9.3,-4.2).lineTo(8.2,-4.2).curveTo(7.6,-4.2,7.2,-3.9).lineTo(6.4,-3.2).lineTo(4,0.1).lineTo(6.2,9).closePath();
	this.shape_3.setTransform(10.175,22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,0.3,74.8,31.099999999999998);


(lib.INET = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#E0DD00","#D9DA08","#C5D31F","#ABC93D","#A3C63F","#91C043","#8DBE3B","#81B924","#79B616"],[0,0.106,0.271,0.439,0.675,0.976,0.984,0.996,1],-45.5,-10.9,49.4,11.9).beginStroke().moveTo(29.7,3.7).lineTo(31.2,-1.9).lineTo(31.7,-1.9).lineTo(31.6,-1.3).curveTo(32.4,-2,33.3,-2).curveTo(34.6,-2,34,0.1).curveTo(33.5,2.1,32.1,2.1).curveTo(31.4,2.1,30.8,1.7).lineTo(30.3,3.7).closePath().moveTo(31.5,-0.8).lineTo(31,1.3).curveTo(31.6,1.5,32.1,1.5).curveTo(33,1.5,33.4,0.1).curveTo(33.6,-0.8,33.5,-1.1).curveTo(33.4,-1.4,33,-1.4).curveTo(32.5,-1.4,31.5,-0.8).closePath().moveTo(0.6,3.7).lineTo(2.1,-1.9).lineTo(2.6,-1.9).lineTo(2.5,-1.3).curveTo(3.3,-2,4.2,-2).curveTo(5.5,-2,4.9,0.1).curveTo(4.4,2.1,3,2.1).curveTo(2.3,2.1,1.7,1.7).lineTo(1.2,3.7).closePath().moveTo(2.4,-0.8).lineTo(1.9,1.3).curveTo(2.5,1.5,3,1.5).curveTo(3.9,1.5,4.3,0.1).curveTo(4.7,-1.4,3.9,-1.4).curveTo(3.3,-1.4,2.4,-0.8).closePath().moveTo(-21.2,3.7).lineTo(-19.7,-1.9).lineTo(-19.2,-1.9).lineTo(-19.3,-1.3).curveTo(-18.5,-2,-17.6,-2).curveTo(-16.3,-2,-16.9,0.1).curveTo(-17.4,2.1,-18.8,2.1).curveTo(-19.5,2.1,-20.1,1.7).lineTo(-20.6,3.7).closePath().moveTo(-19.4,-0.8).lineTo(-20,1.3).curveTo(-19.2,1.5,-18.8,1.5).curveTo(-18.3,1.5,-18.1,1.2).curveTo(-17.8,0.9,-17.5,0.1).curveTo(-17.3,-0.8,-17.4,-1.1).curveTo(-17.5,-1.4,-18,-1.4).curveTo(-18.5,-1.4,-19.4,-0.8).closePath().moveTo(24.7,3.2).lineTo(25,2).lineTo(22,2).lineTo(21.6,3.2).lineTo(21.2,3.2).lineTo(21.6,1.5).lineTo(22.1,1.5).curveTo(22.9,0.3,23.3,-1).curveTo(23.6,-1.9,24.5,-1.9).lineTo(26,-1.9).lineTo(25.1,1.5).lineTo(25.6,1.5).lineTo(25.1,3.2).closePath().moveTo(23.8,-0.9).curveTo(23.4,0.5,22.6,1.5).lineTo(24.5,1.5).lineTo(25.2,-1.4).lineTo(24.4,-1.4).curveTo(24.1,-1.4,23.8,-0.9).closePath().moveTo(26.5,1.7).curveTo(26.2,1.2,26.5,0).curveTo(26.9,-1.1,27.4,-1.6).curveTo(27.9,-2,28.8,-2).curveTo(30.4,-2,30,-0.7).curveTo(29.7,0.4,28.9,0.4).lineTo(27.1,0.4).curveTo(27,1.1,27.2,1.3).curveTo(27.4,1.5,28,1.5).lineTo(29.3,1.4).lineTo(29.2,1.9).curveTo(28.8,2.1,27.7,2.1).curveTo(26.8,2.1,26.5,1.7).closePath().moveTo(27.8,-1.2).curveTo(27.5,-0.9,27.3,-0.2).lineTo(28.8,-0.2).curveTo(29.3,-0.2,29.4,-0.7).curveTo(29.6,-1.4,28.7,-1.4).curveTo(28.1,-1.4,27.8,-1.2).closePath().moveTo(5.6,1.7).curveTo(5.3,1.2,5.6,0).curveTo(6,-1.1,6.5,-1.6).curveTo(7,-2,8,-2).curveTo(8.9,-2,9.2,-1.6).curveTo(9.4,-1.1,9.1,0).curveTo(8.8,1.2,8.3,1.7).curveTo(7.8,2.1,6.8,2.1).curveTo(5.9,2.1,5.6,1.7).closePath().moveTo(6.9,-1.1).curveTo(6.5,-0.8,6.3,0).curveTo(6.1,0.9,6.2,1.2).curveTo(6.4,1.5,7,1.5).curveTo(7.6,1.5,7.9,1.2).curveTo(8.2,0.9,8.5,0).curveTo(8.7,-0.8,8.5,-1.1).curveTo(8.4,-1.4,7.8,-1.4).curveTo(7.2,-1.4,6.9,-1.1).closePath().moveTo(-11.9,1.7).curveTo(-12.2,1.2,-11.9,0).curveTo(-11.3,-2,-9.7,-2).curveTo(-8,-2,-8.4,-0.7).curveTo(-8.7,0.4,-9.6,0.4).lineTo(-11.3,0.4).curveTo(-11.5,1.1,-11.3,1.3).curveTo(-11.1,1.5,-10.5,1.5).lineTo(-9.1,1.4).lineTo(-9.2,1.9).curveTo(-9.7,2.1,-10.7,2.1).curveTo(-11.7,2.1,-11.9,1.7).closePath().moveTo(-10.6,-1.2).curveTo(-11,-0.9,-11.2,-0.2).lineTo(-9.6,-0.2).curveTo(-9.2,-0.2,-9.1,-0.7).curveTo(-8.9,-1.4,-9.8,-1.4).curveTo(-10.4,-1.4,-10.6,-1.2).closePath().moveTo(-24.4,1.7).curveTo(-24.7,1.2,-24.4,0).curveTo(-24.1,-1.1,-23.5,-1.6).curveTo(-23,-2,-22.1,-2).curveTo(-20.6,-2,-20.9,-0.7).curveTo(-21.2,0.4,-22.1,0.4).lineTo(-23.8,0.4).curveTo(-23.9,1.1,-23.7,1.3).curveTo(-23.5,1.5,-22.9,1.5).lineTo(-21.6,1.4).lineTo(-21.7,1.9).curveTo(-22.2,2.1,-23.2,2.1).curveTo(-24.1,2.1,-24.4,1.7).closePath().moveTo(-23.1,-1.2).curveTo(-23.5,-0.9,-23.7,-0.2).lineTo(-22.1,-0.2).curveTo(-21.7,-0.2,-21.5,-0.7).curveTo(-21.4,-1.4,-22.3,-1.4).curveTo(-22.9,-1.4,-23.1,-1.2).closePath().moveTo(13.6,1).lineTo(13.7,0.6).curveTo(14,-0.4,15,-0.4).lineTo(16.6,-0.4).lineTo(16.6,-0.8).curveTo(16.7,-0.9,16.7,-1).curveTo(16.7,-1,16.7,-1.1).curveTo(16.7,-1.2,16.7,-1.2).curveTo(16.7,-1.2,16.6,-1.3).curveTo(16.5,-1.4,16.1,-1.4).lineTo(14.5,-1.3).lineTo(14.5,-1.9).lineTo(16.4,-2).curveTo(17.6,-2,17.3,-0.8).lineTo(16.5,2).lineTo(16,2).lineTo(16.1,1.4).curveTo(15.3,2.1,14.4,2.1).curveTo(13.3,2.1,13.6,1).closePath().moveTo(14.4,0.7).lineTo(14.3,0.9).curveTo(14.1,1.5,14.7,1.5).curveTo(15.4,1.5,16.2,0.9).lineTo(16.4,0.1).lineTo(15,0.1).curveTo(14.5,0.1,14.4,0.7).closePath().moveTo(9.5,2).lineTo(10.5,-1.9).lineTo(12,-2).curveTo(12.9,-2,13.2,-1.8).curveTo(13.5,-1.5,13.3,-0.9).curveTo(13.1,-0.1,12.3,-0).curveTo(13.2,0.1,12.9,1).curveTo(12.8,1.6,12.4,1.9).curveTo(12,2.1,11.2,2.1).closePath().moveTo(10.2,1.5).lineTo(11.2,1.5).curveTo(12.1,1.5,12.3,0.9).curveTo(12.5,0.2,11.5,0.2).lineTo(10.6,0.2).closePath().moveTo(10.7,-0.3).lineTo(11.7,-0.3).curveTo(12.6,-0.3,12.7,-0.9).curveTo(12.9,-1.4,11.9,-1.4).lineTo(11,-1.4).closePath().moveTo(20.2,2).lineTo(20.9,-0.6).lineTo(21.1,-1.1).lineTo(21.1,-1.1).lineTo(20.7,-0.7).lineTo(18.1,2).lineTo(17.6,2).lineTo(18.6,-1.9).lineTo(19.2,-1.9).lineTo(18.5,0.7).lineTo(18.3,1.2).lineTo(18.4,1.2).lineTo(18.7,0.8).lineTo(21.4,-1.9).lineTo(21.9,-1.9).lineTo(20.8,2).closePath().moveTo(-0.7,2).lineTo(0.2,-1.4).lineTo(-1.7,-1.4).lineTo(-2.6,2).lineTo(-3.2,2).lineTo(-2.1,-1.9).lineTo(1,-1.9).lineTo(-0,2).closePath().moveTo(-7.4,2).lineTo(-6.5,-1.4).lineTo(-7.8,-1.4).lineTo(-7.7,-1.9).lineTo(-4.3,-1.9).lineTo(-4.5,-1.4).lineTo(-5.8,-1.4).lineTo(-6.7,2).closePath().moveTo(-13.9,2).lineTo(-13.4,0.2).lineTo(-15.4,0.2).lineTo(-15.9,2).lineTo(-16.5,2).lineTo(-15.5,-1.9).lineTo(-14.8,-1.9).lineTo(-15.3,-0.3).lineTo(-13.3,-0.3).lineTo(-12.9,-1.9).lineTo(-12.2,-1.9).lineTo(-13.3,2).closePath().moveTo(-27.3,2).lineTo(-26.4,-1.4).lineTo(-27.7,-1.4).lineTo(-27.6,-1.9).lineTo(-24.3,-1.9).lineTo(-24.4,-1.4).lineTo(-25.8,-1.4).lineTo(-26.7,2).closePath().moveTo(-29.9,2).lineTo(-29.4,0.2).lineTo(-31.4,0.2).lineTo(-31.9,2).lineTo(-32.5,2).lineTo(-31.5,-1.9).lineTo(-30.8,-1.9).lineTo(-31.2,-0.3).lineTo(-29.3,-0.3).lineTo(-28.9,-1.9).lineTo(-28.2,-1.9).lineTo(-29.3,2).closePath().moveTo(-34.2,2).lineTo(-33.2,-1.9).lineTo(-32.5,-1.9).lineTo(-33.6,2).closePath().moveTo(19.6,-2.9).curveTo(19.4,-3.2,19.6,-3.7).lineTo(20.1,-3.7).curveTo(19.8,-3,20.5,-3).curveTo(21.2,-3,21.3,-3.7).lineTo(21.8,-3.7).curveTo(21.8,-3.2,21.4,-2.9).curveTo(20.9,-2.6,20.4,-2.6).curveTo(19.9,-2.6,19.6,-2.9).closePath().moveTo(-32.8,-2.7).curveTo(-32.8,-2.7,-32.9,-2.7).curveTo(-32.9,-2.7,-32.9,-2.8).curveTo(-32.9,-2.8,-32.9,-2.8).curveTo(-32.9,-2.9,-32.9,-2.9).lineTo(-32.8,-3.4).curveTo(-32.8,-3.5,-32.8,-3.5).curveTo(-32.7,-3.5,-32.7,-3.6).curveTo(-32.7,-3.6,-32.6,-3.6).curveTo(-32.6,-3.6,-32.6,-3.6).lineTo(-32.3,-3.6).curveTo(-32.2,-3.6,-32.2,-3.6).curveTo(-32.1,-3.6,-32.1,-3.6).curveTo(-32.1,-3.5,-32.1,-3.5).curveTo(-32.1,-3.5,-32.1,-3.4).lineTo(-32.2,-2.9).curveTo(-32.2,-2.9,-32.3,-2.8).curveTo(-32.3,-2.8,-32.3,-2.8).curveTo(-32.3,-2.7,-32.4,-2.7).curveTo(-32.4,-2.7,-32.5,-2.7).closePath();
	this.shape.setTransform(33.6197,3.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-0.4,68.5,7.300000000000001);


(lib.Scene_1_KOM = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// KOM
	this.instance = new lib.KOM("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(54.1,15.35,1,1,0,0,0,37.4,15.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({_off:false},0).to({x:112.6},20).wait(126));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_inet1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// inet1
	this.instance = new lib.INET("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(107.85,36.55,1,1,0,0,0,34.2,3.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(44).to({_off:false},0).to({alpha:1},8).wait(115));

}).prototype = p = new cjs.MovieClip();


(lib.OPTI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.opti1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(40.15,12.55,1,1,0,0,0,39.6,12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.6,0.6,79.30000000000001,23.9);


(lib.Scene_1_OPTI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// OPTI
	this.instance = new lib.OPTI("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(117.2,11.75,1,1,0,0,0,39.6,12);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:39.65},20).wait(147));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib.OptiKomlogo_7S = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_166 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(166).call(this.frame_166).wait(1));

	// inet1_obj_
	this.inet1 = new lib.Scene_1_inet1();
	this.inet1.name = "inet1";
	this.inet1.parent = this;
	this.inet1.depth = 0;
	this.inet1.isAttachedToCamera = 0
	this.inet1.isAttachedToMask = 0
	this.inet1.layerDepth = 0
	this.inet1.layerIndex = 0
	this.inet1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.inet1).wait(167));

	// komMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.moveTo(20.6,17).lineTo(-38.6,17).lineTo(-29.6,-16.4).lineTo(-29.4,-17).lineTo(38.6,-17).lineTo(38.6,17).closePath();
	mask.setTransform(111.9,15.625);

	// KOM_obj_
	this.KOM = new lib.Scene_1_KOM();
	this.KOM.name = "KOM";
	this.KOM.parent = this;
	this.KOM.depth = 0;
	this.KOM.isAttachedToCamera = 0
	this.KOM.isAttachedToMask = 0
	this.KOM.layerDepth = 0
	this.KOM.layerIndex = 1
	this.KOM.maskLayerName = 0

	var maskedShapeInstanceList = [this.KOM];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.KOM).wait(167));

	// optiMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.moveTo(-24.2,16.4).lineTo(-41.6,16.4).lineTo(-41.6,-16.4).lineTo(41.6,-16.4).lineTo(40.7,-13).lineTo(32.7,16.4).closePath();
	mask_1.setTransform(41.675,12.175);

	// OPTI_obj_
	this.OPTI = new lib.Scene_1_OPTI();
	this.OPTI.name = "OPTI";
	this.OPTI.parent = this;
	this.OPTI.setTransform(117.8,12.3,1,1,0,0,0,117.8,12.3);
	this.OPTI.depth = 0;
	this.OPTI.isAttachedToCamera = 0
	this.OPTI.isAttachedToMask = 0
	this.OPTI.layerDepth = 0
	this.OPTI.layerIndex = 2
	this.OPTI.maskLayerName = 0

	var maskedShapeInstanceList = [this.OPTI];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.OPTI).wait(167));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(75.6,20.1,74.1,19.799999999999997);
// library properties:
lib.properties = {
	id: '98904A1271040F4791D8B416DB1F4233',
	width: 150,
	height: 40,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['98904A1271040F4791D8B416DB1F4233'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;